create function test(first_id int, last_id int)
  returns int
  BEGIN
	#Routine body goes here...	
	while first_id <= last_id do
	insert into tree(id, name, value, parentid) values(first_id, CONCAT('level', first_id), first_id, first_id-1);
	set first_id = first_id + 1;
	end while;
	
	
	RETURN last_id;
END;

