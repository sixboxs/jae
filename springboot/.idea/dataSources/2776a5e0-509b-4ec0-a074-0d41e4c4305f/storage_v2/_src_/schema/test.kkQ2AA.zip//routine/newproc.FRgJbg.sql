create procedure NewProc()
  BEGIN
	#Routine body goes here...
	select * from tree;
	select count(id) from tree;
END;

